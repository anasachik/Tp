import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart' ;

class GallerDataPage extends StatefulWidget {
  String keyword;

  GallerDataPage(this.keyword);

  @override
  _GallerDataPageState createState() => _GallerDataPageState();
}

class _GallerDataPageState extends State<GallerDataPage> {
  int currentPage = 1;
  int size = 10;
  int totalpages;
  ScrollController _scrollController = new ScrollController();
  List<dynamic> hits=[];
  var galleryData;
  @override
  void initState(){
    super.initState();
    this.getData();
    _scrollController.addListener((){
      if(_scrollController.position.pixels == _scrollController.position.maxScrollExtent){
        if(currentPage< totalpages){
          ++currentPage;
          this.getData();
        }
        ++currentPage;
        this.getData();
      }
    });
  }

  @override
  void dispose(){
    super.dispose();

  }

  void getData() {
    String url = "https://pixabay.com/api/?key=12261714-a77435abc11e36719d043a8cb&q=${widget.keyword}&page=${currentPage}&per_page=${size}";
    http.get(url).then((res){
      setState(() {
        this.galleryData = json.decode(res.body);
        hits += galleryData['hits'];
        if(galleryData['totalHits']%size ==0){
          totalpages = galleryData['totalHits']~/size;
        }
        else{
          totalpages = 1 + galleryData['totalHits']/size.floor();//division entiere
        }
        print(hits);
      });
    }).catchError((err){
      print(err);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.keyword}, Page ${currentPage}/${totalpages}'),
        backgroundColor: Colors.black ,
      ),
      body: (galleryData==null?
      Center(child: CircularProgressIndicator() ,):
      ListView.builder(
          itemCount: (galleryData==null?0:hits.length),
          controller: _scrollController,
          itemBuilder: (context,index){
            return Column(
              children: <Widget>[
                Container(
                  width:double.infinity ,
                  padding: EdgeInsets.all(10),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(10),
                      child: Text(
                        hits[index]['tags'],
                        style: TextStyle(
                          fontSize: 23, color: Colors.yellow,
                        ),
                      ),
                    ),
                    color : Colors.black87
                ),
                  
                ),
                Container(

                  child: Card(
                    child: Image.network(hits[index]['webformatURL']
                    ,fit: BoxFit.fitWidth,),
                  ),
                  padding: EdgeInsets.only(left: 10, right: 10),
                )
              ],
            );
          })
      )
    );
  }


}
