import 'package:flutter/material.dart';

class Quiz extends StatefulWidget{
  @override
  _QuizState createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  int currentQuestion =0;
  int score = 0;
  var quiz = [
    {
      "title":"Question 1",
      "answers":[
        {
          "answer":"aswer 11",
          "correct": false
        },{
          "answer":"aswer 12",
          "correct": true
        },{
          "answer":"aswer 13",
          "correct": false
        },
      ]
    },
    {
      "title":"Question 2",
      "answers":[
        {
          "answer":"aswer 21",
          "correct": false
        },{
          "answer":"aswer 22",
          "correct": false
        },{
          "answer":"aswer 23",
          "correct": true
        },
      ]
    },
    {
      "title":"Question 3",
      "answers":[
        {
          "answer":"aswer 31",
          "correct": true
        },{
          "answer":"aswer 32",
          "correct": false
        },{
          "answer":"aswer 33",
          "correct": false
        },
      ]
    }
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
      ),
      body:
      (this.currentQuestion >=quiz.length)?
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Score : ${(100*score/quiz.length).round()} %",style: TextStyle(fontSize: 22, color: Colors.black),),
                MaterialButton(
                  onPressed: (){
                    setState(() {
                      this.currentQuestion = 0;
                      this.score = 0;
                    });
                  },
                  child: Text("Restart",style: TextStyle(color: Colors.white, fontSize: 23,backgroundColor: Colors.black),),
                )
              ],
            )
          )
      : ListView(
          children: <Widget>[
            ListTile(
              title: Center(child: Text("Question ${currentQuestion+1}/${quiz.length}",
              style: TextStyle(fontSize: 22, color: Colors.black, fontWeight: FontWeight.bold),))
            ),
            ListTile(
                title: Text(quiz[currentQuestion]['title'],style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),),
            ),
            ...(quiz[currentQuestion]['answers'] as List<Map<String,Object>>).map((answer){
              return RaisedButton(
                color: Colors.lightBlue,
                padding: const EdgeInsets.all(12.0),
                onPressed: (){
                  setState(() {
                    if(answer['correct'] == true){
                      ++score;
                    }
                    ++currentQuestion;
                  });
                },
                child: Text(answer['answer']),
              );
            })
          ],
      )
    );
  }
}