import 'package:first_flutter_app/camera.dart';
import 'package:first_flutter_app/gallery.dart';
import 'package:first_flutter_app/maine-drawer.dart';
import 'package:first_flutter_app/weather.dart';
import 'package:flutter/material.dart';
import 'quiz.dart';

void main(){
//  runApp(MyHomePage());
  runApp(MaterialApp(home: MyHomePage(),));
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
//    return MaterialApp(
//      home: Center(
//        child: Text("God is The Greatest"),
//      ),
//    );
    return Scaffold(
        drawer: MainDrawer(),
        appBar: AppBar(title: Text('My APP'), backgroundColor: Colors.black,),
        body: Center(
          child: Text('Main APP', style: TextStyle(fontSize: 22, color: Colors.grey), )),
    );
  }

}
//stful & stless shortcut